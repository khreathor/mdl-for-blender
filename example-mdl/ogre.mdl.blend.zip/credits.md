· model by lavender.pet 
· texture by lavender.pet & millenia3d 
· rig by Mr.M & kebbyquake
· animation by nolcoz
